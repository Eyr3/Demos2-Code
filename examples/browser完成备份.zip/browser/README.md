## Browser examples

Browser examples using the milagro-crypto-js library, for example;

    cp -r ../../src .
    ln -s example_AES_ENCRYPTION.html  index.html
    busybox httpd -f -p 8000

Open this url in your browser

    127.0.0.1:8000

and look at the output in the browser's console.
